# 🛡️ PhishingGuard AI — Browser Security Extension

AI-powered phishing protection with Kenyan government institution impersonation detection.

---

## Features

- **AI Phishing Detection** — TensorFlow.js neural network + heuristic analysis
- **Kenyan Gov Impersonation Detection** — Detects fake IEBC, KRA, eCitizen, HELB, NTSA, SHA, NHIF, NSSF, Kenya Power, and more
- **Global Brand Protection** — Google, Microsoft, PayPal, Facebook, Amazon, Apple, Safaricom, M-Pesa, Equity Bank, KCB
- **Adult Content Blocking** — Immediate block with no bypass option
- **User Blacklist** — Manually block any domain
- **Scan History** — IndexedDB-backed history of all scans
- **Popup Dashboard** — Live statistics and controls

---

## Installation

### Chrome / Edge / Brave / Opera (Chromium)

1. Open `chrome://extensions`
2. Enable **Developer Mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `phishingguard-ai-extension` folder

### Firefox

1. Open `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on**
3. Select the `manifest.json` file inside the folder

---

## How It Works

### Kenyan Institution Impersonation

The extension maintains an official whitelist of Kenyan government domains:

| Institution | Official Domain |
|---|---|
| IEBC | iebc.or.ke |
| KRA | kra.go.ke, itax.kra.go.ke |
| eCitizen | ecitizen.go.ke |
| SHA | sha.go.ke |
| HELB | helb.co.ke |
| NTSA | ntsa.go.ke |
| Kenya Power | kplc.co.ke, kenyapower.co.ke |
| NSSF | nssf.or.ke |
| NHIF | nhif.or.ke |
| Ministry of Education | education.go.ke |
| Kenya Police | nationalpolice.go.ke |
| Kenya Judiciary | judiciary.go.ke |
| Central Bank of Kenya | centralbank.go.ke |

When any page **mentions** one of these institutions but **is not on the official domain**, it is immediately blocked with a government impersonation warning.

**Example:**
```
URL: https://www.ctretz.online/iebc-or-ke-jobs
Result: BLOCKED — IEBC impersonation
Reason: Page mentions "IEBC" but domain is ctretz.online (not iebc.or.ke)
```

### Warning Page

The warning page shows:
- ⚠ Institution name being impersonated
- Official website URL
- Current (fraudulent) domain
- Risk score and threat type
- "Go Back To Safety" button
- "Proceed Anyway" button (only for standard phishing, NOT for adult/blacklisted/gov impersonation)

### Adult Content Blocking

Domains matching adult keywords are **immediately blocked** with **no bypass option**.

### ML Model

The neural network uses 15 URL/page features:
- URL length, dot count, hyphen count
- Digit ratio in hostname
- Suspicious keywords in URL
- HTTPS usage
- IP address as hostname
- Subdomain depth
- Path depth and query strings
- Brand name in URL without official domain
- Password form presence
- External link ratio
- Homograph/lookalike domain similarity
- Kenyan institution keyword in URL

---

## File Structure

```
phishingguard-ai-extension/
├── manifest.json          # WebExtensions Manifest V3
├── background.js          # Service worker — scanning & blocking
├── content.js             # Page content extractor
├── config.js              # Whitelists, brands, keywords
├── ml.js                  # TensorFlow.js + heuristic engine
├── db.js                  # IndexedDB scan history
├── popup.html / popup.js  # Extension popup dashboard
├── warning.html / warning.js  # Phishing block page
├── model/
│   ├── model.json         # TF.js neural network topology
│   └── group1-shard1of1.bin  # Model weights
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## Upgrading the ML Model

To train and replace the model with a production-grade one:

1. Collect URL dataset (phishing + legitimate URLs)
2. Extract the 15 features from `ml.js → extractFeatures()`
3. Train a binary classifier in Python with TensorFlow/Keras
4. Export: `model.save('model_tfjs', save_format='tf')` then convert with `tensorflowjs_converter`
5. Replace `model/model.json` and `model/group1-shard1of1.bin`

---

## Privacy

All scanning happens **locally in your browser**. No data is sent to external servers.
Scan history is stored locally in IndexedDB and can be cleared from the popup.
