// ============================================================
// PhishingGuard AI — Central Configuration
// Classic script (no ES modules) — loaded via importScripts
// ============================================================

const API = typeof browser !== "undefined" ? browser : chrome;

const OFFICIAL_KENYAN_DOMAINS = {
  "IEBC":                    ["iebc.or.ke"],
  "KRA":                     ["kra.go.ke", "itax.kra.go.ke"],
  "eCitizen":                ["ecitizen.go.ke"],
  "SHA":                     ["sha.go.ke"],
  "HELB":                    ["helb.co.ke"],
  "NTSA":                    ["ntsa.go.ke"],
  "Kenya Power":             ["kplc.co.ke", "kenyapower.co.ke"],
  "NSSF":                    ["nssf.or.ke"],
  "NHIF":                    ["nhif.or.ke"],
  "Kenya Revenue Authority": ["kra.go.ke"],
  "Ministry of Education":   ["education.go.ke"],
  "Kenya Police":            ["nationalpolice.go.ke"],
  "Kenya Judiciary":         ["judiciary.go.ke"],
  "Central Bank of Kenya":   ["centralbank.go.ke"]
};

const KENYAN_INSTITUTION_KEYWORDS = {
  "IEBC":                    ["IEBC", "Independent Electoral", "Boundaries Commission", "voter registration"],
  "KRA":                     ["KRA", "Kenya Revenue Authority", "iTax", "tax refund kenya", "kra pin"],
  "eCitizen":                ["eCitizen", "ecitizen kenya", "government services kenya"],
  "SHA":                     ["SHA", "Social Health Authority", "sha kenya"],
  "HELB":                    ["HELB", "Higher Education Loans Board", "helb loan"],
  "NTSA":                    ["NTSA", "National Transport Safety Authority", "tims kenya"],
  "Kenya Power":             ["Kenya Power", "KPLC", "kplc token", "kenya power bill"],
  "NSSF":                    ["NSSF", "National Social Security Fund"],
  "NHIF":                    ["NHIF", "National Hospital Insurance Fund"],
  "Kenya Revenue Authority": ["Kenya Revenue Authority"],
  "Ministry of Education":   ["Ministry of Education Kenya", "TSC Kenya"],
  "Kenya Police":            ["Kenya Police", "DCI Kenya"],
  "Kenya Judiciary":         ["Kenya Judiciary", "court kenya"],
  "Central Bank of Kenya":   ["Central Bank of Kenya", "CBK"]
};

const BRAND_DOMAINS = {
  "Google":       { official: ["google.com", "google.co.ke", "gmail.com", "accounts.google.com"], keywords: ["google", "gmail", "google account"] },
  "Microsoft":    { official: ["microsoft.com", "live.com", "outlook.com", "office.com", "microsoftonline.com"], keywords: ["microsoft", "outlook", "office 365", "windows"] },
  "PayPal":       { official: ["paypal.com", "paypal.me"], keywords: ["paypal", "pay pal"] },
  "Facebook":     { official: ["facebook.com", "fb.com", "messenger.com"], keywords: ["facebook", "fb login", "facebook account"] },
  "Amazon":       { official: ["amazon.com", "amazon.co.uk", "amazon.co.ke"], keywords: ["amazon", "amazon prime"] },
  "Apple":        { official: ["apple.com", "icloud.com"], keywords: ["apple id", "icloud", "apple account"] },
  "Netflix":      { official: ["netflix.com"], keywords: ["netflix", "netflix account"] },
  "WhatsApp":     { official: ["whatsapp.com"], keywords: ["whatsapp", "whatsapp account"] },
  "Equity Bank":  { official: ["equitybank.co.ke", "equitybankgroup.com"], keywords: ["equity bank", "equitel"] },
  "KCB Bank":     { official: ["kcbgroup.com", "kcb.co.ke"], keywords: ["kcb", "kcb bank"] },
  "Safaricom":    { official: ["safaricom.co.ke"], keywords: ["safaricom", "mpesa", "m-pesa", "bonga points"] },
  "M-Pesa":       { official: ["safaricom.co.ke", "mpesa.co.ke"], keywords: ["mpesa", "m-pesa", "lipa na mpesa", "paybill"] },
  "Stanbic Bank": { official: ["stanbicbank.co.ke"], keywords: ["stanbic bank kenya"] },
  "ABSA Kenya":   { official: ["absa.co.ke"], keywords: ["absa kenya"] }
};

const ADULT_KEYWORDS = [
  "porn", "pornhub", "xvideos", "xnxx", "redtube", "youporn",
  "xxx", "hentai", "sex", "nude", "adult", "cam4", "chaturbate",
  "livejasmin", "bongacams", "stripchat", "onlyfans", "fansly",
  "brazzers", "bangbros", "naughtyamerica"
];

const PHISHING_URL_KEYWORDS = [
  "login", "verify", "secure", "account", "update", "confirm",
  "banking", "password", "credential", "signin", "sign-in",
  "webscr", "free", "bonus", "winner", "promo", "offer", "gift",
  "prize", "claim", "reward", "jobs2026", "taxrefund", "tax-refund",
  "loan-application", "benefits-check", "pin-reset", "portal-login"
];

const HOMOGRAPH_MAP = {
  "0": "o", "1": "l", "3": "e", "4": "a",
  "5": "s", "6": "b", "7": "t", "@": "a", "vv": "w"
};
