// ============================================================
// PhishingGuard AI — Content Script (content.js)
// ============================================================

const API = typeof browser !== "undefined" ? browser : chrome;

// Skip extension pages entirely
if (window.location.href.startsWith("chrome-extension://") ||
    window.location.href.startsWith("moz-extension://")) {
  // Do nothing
} else {
  // Check if user already bypassed this exact URL — don't re-scan and loop
  const bypassKey = "phishguard_bypass_" + window.location.href;
  const alreadyBypassed = sessionStorage.getItem(bypassKey) === "1";

  if (!alreadyBypassed) {
    if (document.readyState === "complete") {
      setTimeout(extractAndScan, 1500);
    } else {
      window.addEventListener("load", function onLoad() {
        window.removeEventListener("load", onLoad);
        setTimeout(extractAndScan, 800);
      });
    }
  }
}

function extractAndScan() {
  try {
    const href = window.location.href;
    if (href.startsWith("chrome-extension://") || href.startsWith("moz-extension://")) return;

    // Skip if user bypassed this URL this session
    const bypassKey = "phishguard_bypass_" + href;
    if (sessionStorage.getItem(bypassKey) === "1") return;

    const bodyText = (document.body && document.body.innerText) || "";
    // Wait for real content — retry once if page still loading
    if (bodyText.trim().length < 20) {
      setTimeout(extractAndScan, 2000);
      return;
    }

    const pageData = {
      pageTitle:         document.title || "",
      pageContent:       bodyText.trim().substring(0, 6000),
      hasPasswordForm:   detectPasswordForms(),
      externalLinkRatio: calcExternalLinkRatio(),
      formCount:         document.querySelectorAll("form").length,
      iframeCount:       document.querySelectorAll("iframe").length,
      hiddenIframes:     detectHiddenIframes(),
      suspiciousScripts: detectSuspiciousScripts(),
      linkCount:         document.querySelectorAll("a[href]").length
    };

    API.runtime.sendMessage(
      { type: "SCAN_PAGE", url: href, pageData },
      (response) => { if (API.runtime.lastError) return; }
    );
  } catch (err) {
    console.debug("[PhishingGuard] Scan error:", err.message);
  }
}

function detectPasswordForms() {
  return document.querySelectorAll("input[type='password']").length > 0;
}

function calcExternalLinkRatio() {
  const links = Array.from(document.querySelectorAll("a[href]"));
  if (!links.length) return 0;
  const host = window.location.hostname;
  let ext = 0;
  for (const l of links) {
    try {
      const h = l.getAttribute("href") || "";
      if (h.startsWith("http") && new URL(h).hostname !== host) ext++;
    } catch {}
  }
  return parseFloat((ext / links.length).toFixed(2));
}

function detectHiddenIframes() {
  for (const f of document.querySelectorAll("iframe")) {
    const s = window.getComputedStyle(f);
    if (s.display === "none" || s.visibility === "hidden" ||
        parseInt(f.width || "1") === 0 || parseInt(f.height || "1") === 0) return true;
  }
  return false;
}

const SUSP_PATTERNS = ["eval(", "document.write(", "window.location.replace(", "atob(", "fromCharCode("];
function detectSuspiciousScripts() {
  for (const s of document.querySelectorAll("script:not([src])")) {
    if (SUSP_PATTERNS.some(p => (s.textContent || "").includes(p))) return true;
  }
  return false;
}

API.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "MANUAL_SCAN") {
    extractAndScan();
    sendResponse({ triggered: true });
  }
});
