// ============================================================
// PhishingGuard AI — Background Service Worker
// ============================================================

importScripts("config.js", "db.js", "ml.js");

// ── Blacklist helpers ─────────────────────────────────────────

async function getBlacklist() {
  return new Promise(resolve =>
    chrome.storage.local.get("blacklist", d => resolve(d.blacklist || []))
  );
}
async function addToBlacklist(domain) {
  const list = await getBlacklist();
  const clean = domain.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  if (clean && !list.includes(clean)) {
    list.push(clean);
    await chrome.storage.local.set({ blacklist: list });
  }
}
async function removeFromBlacklist(domain) {
  const list = await getBlacklist();
  await chrome.storage.local.set({ blacklist: list.filter(d => d !== domain) });
}
async function isBlacklisted(hostname) {
  const list = await getBlacklist();
  const h = hostname.toLowerCase();
  return list.some(d => h === d || h.endsWith("." + d));
}

// ── Bypass token store ────────────────────────────────────────
// Tracks URLs the user has chosen to bypass this session.
// Prevents content script from re-scanning and looping.
const bypassedUrls = new Set();

// ── Warning URL builder ───────────────────────────────────────

function buildWarningUrl(urlStr, hostname, result, scanType) {
  const base = chrome.runtime.getURL("warning.html");
  const ki   = result.kenyanImpersonation;
  const bi   = result.brandImpersonation;
  const params = new URLSearchParams({
    blocked:       urlStr,
    domain:        hostname,
    riskScore:     result.riskScore  || 0,
    riskLevel:     result.riskLevel  || "high",
    reason:        result.reason     || "Threat detected",
    allowBypass:   result.allowBypass ? "1" : "0",
    scanType:      scanType,
    institution:   (ki && ki.institution) || "",
    officialUrl:   (ki && ki.officialUrl) || (bi && bi.officialUrl) || "",
    currentDomain: (ki && ki.currentDomain) || hostname
  });
  return base + "?" + params.toString();
}

async function handleBlock(tabId, urlStr, hostname, result, scanType) {
  chrome.tabs.update(tabId, { url: buildWarningUrl(urlStr, hostname, result, scanType) });
}

// ── Core scan ─────────────────────────────────────────────────

async function runScan(tabId, urlStr, pageData) {
  let hostname = "";
  try { hostname = new URL(urlStr).hostname.toLowerCase(); } catch {}

  // Never block official Kenyan govt domains
  if (isOfficialKenyanDomain(hostname)) return { shouldBlock: false };

  // Never block official global brand domains
  if (isOfficialBrandDomain(hostname)) return { shouldBlock: false };

  // Skip if user already bypassed this URL
  if (bypassedUrls.has(urlStr)) return { shouldBlock: false };

  // Check user blacklist — no bypass
  if (await isBlacklisted(hostname)) {
    const result = {
      riskScore: 1, riskLevel: "high", shouldBlock: true, allowBypass: false,
      reason: "Domain is in your blacklist",
      kenyanImpersonation: null, brandImpersonation: null, impersonation: null
    };
    await saveScan({ url: urlStr, domain: hostname, detectedBrand: "",
      scanResult: "blacklisted", mlConfidence: 1,
      userAction: "blocked", reason: result.reason });
    await handleBlock(tabId, urlStr, hostname, result, "blacklisted");
    return result;
  }

  const result   = predict(urlStr, pageData);
  const scanType = result.scanType || (result.shouldBlock ? "phishing" : "safe");

  await saveScan({
    url:           urlStr,
    domain:        hostname,
    detectedBrand: (result.kenyanImpersonation && result.kenyanImpersonation.institution)
                || (result.brandImpersonation  && result.brandImpersonation.brand) || "",
    scanResult:    scanType === "safe" ? "safe" : scanType,
    mlConfidence:  result.riskScore,
    userAction:    result.shouldBlock ? "blocked" : "allowed",
    reason:        result.reason
  });

  if (result.shouldBlock) {
    await handleBlock(tabId, urlStr, hostname, result, scanType);
  }
  return result;
}

// ── Message router ────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab && sender.tab.id;

  // Content script sends page data after load
  if (message.type === "SCAN_PAGE") {
    if (!tabId || !message.url ||
        message.url.startsWith("chrome-extension://") ||
        message.url.startsWith("about:") ||
        message.url.startsWith("chrome://")) {
      sendResponse({ success: true, result: { shouldBlock: false } });
      return true;
    }
    // Don't re-scan bypassed URLs
    if (bypassedUrls.has(message.url)) {
      sendResponse({ success: true, result: { shouldBlock: false } });
      return true;
    }
    runScan(tabId, message.url, message.pageData)
      .then(r => sendResponse({ success: true, result: r }))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }

  // User clicked Proceed Anyway — record bypass and navigate
  if (message.type === "BYPASS_NAVIGATE") {
    const url = message.url;
    if (url) {
      bypassedUrls.add(url); // Prevent re-scan loop
      // Also record in background storage for persistence across navigations
      chrome.storage.session && chrome.storage.session.set
        ? chrome.storage.session.set({ ["bypass_" + url]: "1" })
        : null;
    }
    sendResponse({ success: true });
    return true;
  }

  // User chose bypass — just record it (navigation done by warning.js)
  if (message.type === "USER_BYPASS") {
    const url = message.url;
    if (url) bypassedUrls.add(url);
    saveScan({
      url: url, domain: message.domain, detectedBrand: message.brand || "",
      scanResult: "phishing", mlConfidence: message.riskScore || 0,
      userAction: "bypassed", reason: message.reason || "User bypassed warning"
    });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === "GET_CURRENT_RISK") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.url ||
          tab.url.startsWith("chrome://") ||
          tab.url.startsWith("chrome-extension://") ||
          tab.url.startsWith("about:")) {
        return sendResponse({ result: { riskLevel: "low", riskScore: 0 }, url: "" });
      }
      try {
        const result = predict(tab.url, {});
        sendResponse({ result, url: tab.url });
      } catch(e) {
        sendResponse({ result: { riskLevel: "low", riskScore: 0 }, url: tab.url });
      }
    });
    return true;
  }

  if (message.type === "GET_STATS") {
    getStats().then(s => sendResponse(s));
    return true;
  }

  if (message.type === "BLACKLIST_DOMAIN") {
    addToBlacklist(message.domain)
      .then(() => sendResponse({ success: true }))
      .catch(e  => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (message.type === "REMOVE_FROM_BLACKLIST") {
    removeFromBlacklist(message.domain).then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.type === "GET_BLACKLIST") {
    getBlacklist().then(list => sendResponse({ list }));
    return true;
  }
});

// ── webNavigation: only pre-block blacklisted domains ─────────
// All other analysis happens AFTER page load via content script

chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return;
  const url = details.url;
  if (!url || !url.startsWith("http")) return;

  let hostname = "";
  try { hostname = new URL(url).hostname.toLowerCase(); } catch { return; }

  // Never touch whitelisted domains
  if (isOfficialKenyanDomain(hostname) || isOfficialBrandDomain(hostname)) return;

  // Don't re-block bypassed URLs
  if (bypassedUrls.has(url)) return;

  if (await isBlacklisted(hostname)) {
    handleBlock(details.tabId, url, hostname, {
      riskScore: 1, riskLevel: "high", shouldBlock: true, allowBypass: false,
      reason: "Domain is in your blacklist",
      kenyanImpersonation: null, brandImpersonation: null, impersonation: null
    }, "blacklisted");
  }
});
