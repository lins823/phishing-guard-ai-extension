// ============================================================
// PhishingGuard AI — IndexedDB Layer (db.js)
// Classic script — no ES modules
// ============================================================

const DB_NAME    = "PhishingGuardDB";
const DB_VERSION = 1;
const STORE_NAME = "scanHistory";

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "id", autoIncrement: true });
        store.createIndex("url",        "url",        { unique: false });
        store.createIndex("domain",     "domain",     { unique: false });
        store.createIndex("scanResult", "scanResult", { unique: false });
        store.createIndex("timestamp",  "timestamp",  { unique: false });
      }
    };
    request.onsuccess = (e) => resolve(e.target.result);
    request.onerror   = (e) => reject(e.target.error);
  });
}

async function saveScan(record) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(STORE_NAME, "readwrite");
    const req = tx.objectStore(STORE_NAME).add({ ...record, timestamp: Date.now() });
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror   = (e) => reject(e.target.error);
  });
}

async function getAllScans() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).getAll();
    req.onsuccess = (e) => resolve(e.target.result.reverse());
    req.onerror   = (e) => reject(e.target.error);
  });
}

async function getStats() {
  const scans = await getAllScans();
  return {
    total:       scans.length,
    phishing:    scans.filter(s => s.scanResult === "phishing").length,
    adult:       scans.filter(s => s.scanResult === "adult").length,
    blacklisted: scans.filter(s => s.scanResult === "blacklisted").length,
    bypassed:    scans.filter(s => s.userAction  === "bypassed").length,
    safe:        scans.filter(s => s.scanResult  === "safe").length
  };
}

async function clearHistory() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).clear();
    req.onsuccess = () => resolve();
    req.onerror   = (e) => reject(e.target.error);
  });
}
