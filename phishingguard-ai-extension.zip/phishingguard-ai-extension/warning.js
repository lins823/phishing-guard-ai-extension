// ============================================================
// PhishingGuard AI — Warning Page Script (warning.js)
// ============================================================

const API = typeof browser !== "undefined" ? browser : chrome;

document.addEventListener("DOMContentLoaded", () => {
  const p = new URLSearchParams(window.location.search);

  const blockedUrl    = p.get("blocked")      || "";
  const domain        = p.get("domain")        || "";
  const riskScore     = parseFloat(p.get("riskScore") || "0");
  const riskLevel     = p.get("riskLevel")     || "high";
  const reason        = p.get("reason")        || "Threat detected";
  const allowBypass   = p.get("allowBypass")   === "1";
  const scanType      = p.get("scanType")      || "phishing";
  const institution   = p.get("institution")   || "";
  const officialUrl   = p.get("officialUrl")   || "";
  const currentDomain = p.get("currentDomain") || domain;

  const isAdult       = scanType === "adult";
  const isBlacklisted = scanType === "blacklisted";
  const isGovt        = scanType === "govt_impersonation" && institution !== "";
  const isRegular     = !isAdult && !isBlacklisted;   // phishing OR govt — both get Proceed Anyway

  const card = document.getElementById("mainCard");

  // ── Card theme ────────────────────────────────────
  if (isAdult)        card.classList.add("adult-card");
  else if (isGovt)    card.classList.add("govt-card");
  else if (isBlacklisted) card.classList.add("blacklist-card");

  // ── Title / icon ──────────────────────────────────
  const shieldIcon   = document.getElementById("shieldIcon");
  const cardTitle    = document.getElementById("cardTitle");
  const cardSubtitle = document.getElementById("cardSubtitle");

  if (isAdult) {
    shieldIcon.textContent   = "🔞";
    cardTitle.textContent    = "Adult Content Blocked";
    cardSubtitle.textContent = "This site contains adult/explicit content";
  } else if (isBlacklisted) {
    shieldIcon.textContent   = "🚫";
    cardTitle.textContent    = "Blacklisted Site Blocked";
    cardSubtitle.textContent = "You have manually blocked this domain";
  } else if (isGovt) {
    shieldIcon.textContent   = "🏛️";
    cardTitle.textContent    = "Government Impersonation Detected";
    cardSubtitle.textContent = "This site may be impersonating an official Kenyan institution";
  } else {
    shieldIcon.textContent   = "🛡️";
    cardTitle.textContent    = "Phishing Site Blocked";
    cardSubtitle.textContent = "PhishingGuard AI flagged this site as potentially dangerous";
  }

  // ── Govt banner (only for govt_impersonation) ─────
  if (isGovt) {
    const banner = document.getElementById("govtBanner");
    banner.classList.add("visible");
    document.getElementById("govtInstitution").textContent   = institution;
    document.getElementById("govtOfficialUrl").textContent   = officialUrl || "N/A";
    document.getElementById("govtCurrentDomain").textContent = currentDomain;
  }

  // ── Adult notice ──────────────────────────────────
  if (isAdult) document.getElementById("adultNotice").classList.add("visible");

  // ── Risk bar ──────────────────────────────────────
  const riskPct = Math.round(riskScore * 100);
  const fill = document.getElementById("riskBarFill");
  fill.style.width = riskPct + "%";
  if (riskLevel === "medium") fill.classList.add("medium");
  else if (riskLevel === "low") fill.classList.add("low");
  document.getElementById("riskValueLabel").textContent = riskLevel.toUpperCase() + " (" + riskPct + "%)";

  // ── Badges ────────────────────────────────────────
  const badges = document.getElementById("riskBadges");
  const addBadge = (text, cls) => {
    const b = document.createElement("span");
    b.className = "badge " + (cls || "");
    b.textContent = text;
    badges.appendChild(b);
  };
  if (isGovt)       addBadge("Gov Impersonation");
  if (isAdult)      addBadge("Adult Content");
  if (isBlacklisted)addBadge("Blacklisted");
  if (!isAdult && !isBlacklisted && !isGovt) addBadge("Phishing Risk", riskLevel === "medium" ? "amber" : "");
  if (riskScore >= 0.9) addBadge("Critical Threat");

  // ── Reason ────────────────────────────────────────
  document.getElementById("reasonBox").textContent = reason;

  // ── Details ───────────────────────────────────────
  const trunc = (s, n) => s.length > n ? s.slice(0, n) + "…" : s;
  document.getElementById("detailUrl").textContent    = trunc(blockedUrl, 65);
  document.getElementById("detailDomain").textContent = currentDomain;
  document.getElementById("detailScore").textContent  = riskPct + "% (" + riskLevel + ")";
  document.getElementById("detailType").textContent   =
    isAdult       ? "Adult / Explicit Content" :
    isBlacklisted ? "Manually Blacklisted" :
    isGovt        ? "Government Impersonation (" + institution + ")" :
                    "Phishing / Scam Website";

  // ── PROCEED ANYWAY ─────────────────────────────────
  // Shown for ALL non-adult, non-blacklisted blocks (phishing + govt impersonation)
  const btnProceed = document.getElementById("btnProceed");
  if (isRegular && allowBypass && blockedUrl) {
    btnProceed.style.display = "";
    btnProceed.addEventListener("click", function handleProceed() {
      // Remove listener immediately to prevent double-click
      btnProceed.removeEventListener("click", handleProceed);
      btnProceed.disabled = true;
      btnProceed.textContent = "⏳ Redirecting...";

      // Notify background to record bypass
      API.runtime.sendMessage({
        type: "USER_BYPASS", url: blockedUrl, domain: domain,
        brand: institution, riskScore: riskScore, reason: reason
      });

      // Use chrome.tabs.update via background to navigate WITHOUT triggering
      // the content script re-scan loop
      API.runtime.sendMessage(
        { type: "BYPASS_NAVIGATE", url: blockedUrl },
        function() {
          // Fallback: direct navigation (background sets bypass flag first)
          window.location.replace(blockedUrl);
        }
      );
    });
  }

  // ── No-bypass notice (adult / blacklisted only) ───
  if (isAdult || isBlacklisted) {
    document.getElementById("noBypassNotice").style.display = "";
  }

  // ── BLACKLIST THIS DOMAIN button ──────────────────
  // Available for all non-adult, non-blacklisted blocks
  if (!isBlacklisted && !isAdult) {
    const blGroup = document.getElementById("blacklistBtnGroup");
    blGroup.style.display = "";
    document.getElementById("btnBlacklist").addEventListener("click", () => {
      const domainToBlock = currentDomain || domain;
      if (!domainToBlock) return;
      API.runtime.sendMessage({ type: "BLACKLIST_DOMAIN", domain: domainToBlock }, (resp) => {
        if (resp && resp.success) {
          document.getElementById("blToast").classList.add("show");
          document.getElementById("btnBlacklist").disabled = true;
          document.getElementById("btnBlacklist").textContent = "✅ Domain Blacklisted";
          btnProceed.style.display = "none"; // Can't proceed — now blacklisted
        }
      });
    });
  }

  // ── GO BACK button ────────────────────────────────
  document.getElementById("btnGoBack").addEventListener("click", () => {
    if (history.length > 2) {
      history.go(-2);
    } else {
      window.location.href = "https://www.google.com";
    }
  });
});
