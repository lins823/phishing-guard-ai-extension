// ============================================================
// PhishingGuard AI — ML / Heuristic Engine (ml.js)
// ============================================================

function getRootDomain(hostname) {
  if (!hostname) return "";
  const h = hostname.replace(/^www\./, "").toLowerCase();
  const parts = h.split(".");
  const kenyanSuffixes = ["go.ke", "or.ke", "co.ke", "ac.ke", "ne.ke", "sc.ke"];
  for (const suffix of kenyanSuffixes) {
    if (h.endsWith("." + suffix) || h === suffix) return parts.slice(-3).join(".");
  }
  return parts.length >= 2 ? parts.slice(-2).join(".") : h;
}

function domainMatchesOfficial(testHostname, officialDomain) {
  const test     = testHostname.toLowerCase().replace(/^www\./, "");
  const official = officialDomain.toLowerCase().replace(/^www\./, "");
  return test === official || test.endsWith("." + official);
}

function normaliseHomographs(str) {
  let out = str.toLowerCase();
  const map = HOMOGRAPH_MAP || {};
  for (const fake of Object.keys(map)) out = out.split(fake).join(map[fake]);
  return out;
}

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) =>
    Array.from({ length: n + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = a[i-1] === b[j-1] ? dp[i-1][j-1]
        : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
  return dp[m][n];
}

// ── Official domain checks ────────────────────────────────────

function isOfficialKenyanDomain(hostname) {
  if (!hostname) return false;
  const h = hostname.toLowerCase();
  for (const officialList of Object.values(OFFICIAL_KENYAN_DOMAINS || {})) {
    for (const official of officialList) {
      if (domainMatchesOfficial(h, official)) return true;
    }
  }
  return false;
}

// Check if hostname is an official domain for ANY brand (Kenyan or global)
function isOfficialBrandDomain(hostname) {
  const h = hostname.toLowerCase();
  for (const data of Object.values(BRAND_DOMAINS || {})) {
    for (const official of data.official) {
      if (domainMatchesOfficial(h, official)) return true;
    }
  }
  return false;
}

function isAdultContent(urlStr, pageTitle) {
  const combined = (urlStr + " " + (pageTitle || "")).toLowerCase();
  return (ADULT_KEYWORDS || []).some(k => combined.includes(k));
}

// ── Feature extraction ────────────────────────────────────────

function extractFeatures(urlStr, pageData) {
  pageData = pageData || {};
  let url;
  try { url = new URL(urlStr); } catch { return new Array(15).fill(0); }
  const hostname = url.hostname.toLowerCase();
  const fullUrl  = urlStr.toLowerCase();
  const path     = url.pathname.toLowerCase();
  const brands   = BRAND_DOMAINS || {};

  const f0  = Math.min(urlStr.length / 200, 1);
  const f1  = Math.min((fullUrl.match(/\./g)  || []).length / 10, 1);
  const f2  = Math.min((hostname.match(/-/g)  || []).length / 5, 1);
  const f3  = (hostname.match(/\d/g) || []).length / Math.max(hostname.length, 1);
  const f4  = (PHISHING_URL_KEYWORDS || []).some(kw => fullUrl.includes(kw)) ? 1 : 0;
  const f5  = url.protocol === "https:" ? 1 : 0;
  const f6  = /^\d{1,3}(\.\d{1,3}){3}$/.test(hostname) ? 1 : 0;
  const f7  = Math.min(Math.max(hostname.split(".").length - 2, 0) / 5, 1);
  const f8  = Math.min((path.match(/\//g) || []).length / 8, 1);
  const f9  = url.search.length > 0 ? 1 : 0;
  const f10 = 0; // reserved
  const f11 = pageData.hasPasswordForm ? 1 : 0;
  const f12 = (pageData.externalLinkRatio || 0) > 0.5 ? 1 : 0;
  const f13 = 0; // reserved
  const f14 = 0; // reserved

  return [f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14];
}

function heuristicScore(urlStr, pageData) {
  const features = extractFeatures(urlStr, pageData);
  const weights  = [0.05, 0.08, 0.10, 0.12, 0.15, -0.05, 0.20,
                    0.08, 0.04, 0.04, 0.00,  0.15, 0.08,  0.00, 0.00];
  let score = 0;
  for (let i = 0; i < features.length; i++) score += features[i] * weights[i];
  return Math.min(Math.max(score, 0), 1);
}

// ── Kenyan gov impersonation ──────────────────────────────────
// Fires ONLY when:
//   1. Domain is NOT in official Kenyan list
//   2. Page content explicitly mentions the institution keywords
//   3. We have real page content (>100 chars) — not a loading page

function detectKenyanImpersonation(urlStr, hostname, pageContent) {
  if (isOfficialKenyanDomain(hostname)) return null;

  // Only analyse URL path for keyword match, not full page content
  // to reduce false positives on innocent pages that mention govt names
  const urlLower     = urlStr.toLowerCase();
  const contentLower = (pageContent || "").toLowerCase();
  const kenyanKw     = KENYAN_INSTITUTION_KEYWORDS || {};
  const kenyanDoms   = OFFICIAL_KENYAN_DOMAINS || {};

  for (const [institution, keywords] of Object.entries(kenyanKw)) {
    const officialDomains = kenyanDoms[institution] || [];
    if (officialDomains.length === 0) continue;

    // URL path must contain keyword AND page content must also contain it
    // (both required — reduces false positives on news articles etc.)
    const inUrl     = keywords.some(kw => urlLower.includes(kw.toLowerCase()));
    const inContent = keywords.some(kw => contentLower.includes(kw.toLowerCase()));

    if (inUrl && inContent) {
      return {
        detected: true, institution,
        officialDomain: officialDomains[0],
        officialUrl:   "https://" + officialDomains[0],
        currentDomain: getRootDomain(hostname)
      };
    }
  }
  return null;
}

// ── Brand impersonation ───────────────────────────────────────
// Only fires for LOOKALIKE domains (edit distance 1), NOT keyword-only matches.
// Keyword match alone is too broad — "paypal" appears on many legitimate finance pages.

function detectBrandImpersonation(urlStr, hostname, pageContent) {
  // If this is an official domain for any brand, never flag it
  if (isOfficialBrandDomain(hostname) || isOfficialKenyanDomain(hostname)) return null;

  const normHost = normaliseHomographs(hostname.replace(/^www\./, ""));
  const brands   = BRAND_DOMAINS || {};

  for (const [brand, data] of Object.entries(brands)) {
    // Skip if already on official domain
    if (data.official.some(d => domainMatchesOfficial(hostname, d))) continue;

    // Check lookalike domain (edit distance exactly 1 — very strict)
    for (const official of data.official) {
      const officialRoot = getRootDomain(official);
      const dist = levenshtein(normHost, officialRoot);
      // Distance of 1 means one character substitution — classic homograph attack
      if (dist === 1 && normHost !== officialRoot) {
        return {
          detected: true, brand,
          officialDomain: data.official[0],
          officialUrl:   "https://" + data.official[0],
          currentDomain: getRootDomain(hostname),
          lookalike: true
        };
      }
    }
  }
  return null;
}

// ── Master predict ────────────────────────────────────────────

function predict(urlStr, pageData) {
  pageData = pageData || {};
  let hostname = "";
  try { hostname = new URL(urlStr).hostname.toLowerCase(); } catch {}

  const pageContent = pageData.pageContent || "";
  const pageTitle   = pageData.pageTitle   || "";

  // 1. Official Kenyan govt domain → always safe, never block
  if (isOfficialKenyanDomain(hostname)) {
    return {
      riskScore: 0, riskLevel: "low", isAdult: false, isWhitelisted: true,
      shouldBlock: false, allowBypass: false, scanType: "safe",
      impersonation: null, brandImpersonation: null, kenyanImpersonation: null,
      reason: "Official Kenyan government domain — whitelisted"
    };
  }

  // 2. Official global brand domain → always safe, never block
  if (isOfficialBrandDomain(hostname)) {
    return {
      riskScore: 0, riskLevel: "low", isAdult: false, isWhitelisted: true,
      shouldBlock: false, allowBypass: false, scanType: "safe",
      impersonation: null, brandImpersonation: null, kenyanImpersonation: null,
      reason: "Official brand domain — whitelisted"
    };
  }

  // 3. Adult content — no bypass
  if (isAdultContent(urlStr, pageTitle)) {
    return {
      riskScore: 1, riskLevel: "high", isAdult: true, isWhitelisted: false,
      shouldBlock: true, allowBypass: false, scanType: "adult",
      impersonation: null, brandImpersonation: null, kenyanImpersonation: null,
      reason: "Adult / pornographic content detected"
    };
  }

  // 4. Kenyan govt impersonation (requires real page content)
  const kenyanImp = (pageContent.length > 100)
    ? detectKenyanImpersonation(urlStr, hostname, pageContent)
    : null;

  if (kenyanImp && kenyanImp.detected) {
    return {
      riskScore: 0.97, riskLevel: "high", isAdult: false, isWhitelisted: false,
      shouldBlock: true,
      allowBypass: true,  // User CAN proceed (with strong warning)
      scanType: "govt_impersonation",
      impersonation: kenyanImp, brandImpersonation: null, kenyanImpersonation: kenyanImp,
      reason: "Possible impersonation of " + kenyanImp.institution
    };
  }

  // 5. Lookalike brand domain (homograph attack)
  const brandImp = detectBrandImpersonation(urlStr, hostname, pageContent);
  if (brandImp && brandImp.detected) {
    return {
      riskScore: 0.92, riskLevel: "high", isAdult: false, isWhitelisted: false,
      shouldBlock: true, allowBypass: true, scanType: "phishing",
      impersonation: brandImp, brandImpersonation: brandImp, kenyanImpersonation: null,
      reason: "Lookalike domain impersonating " + brandImp.brand
    };
  }

  // 6. Heuristic score for everything else
  const score     = heuristicScore(urlStr, pageData);
  const riskLevel = score >= 0.7 ? "high" : score >= 0.4 ? "medium" : "low";
  const shouldBlock = score >= 0.7;

  const reason = riskLevel === "high"   ? "High phishing risk score"
               : riskLevel === "medium" ? "Suspicious website patterns detected"
               : "No threats detected";

  return {
    riskScore: parseFloat(score.toFixed(3)),
    riskLevel, isAdult: false, isWhitelisted: false,
    shouldBlock, allowBypass: shouldBlock,
    scanType: shouldBlock ? "phishing" : "safe",
    impersonation: null, brandImpersonation: null, kenyanImpersonation: null,
    reason
  };
}
