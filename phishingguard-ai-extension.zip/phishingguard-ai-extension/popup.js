// ============================================================
// PhishingGuard AI — Popup Script (popup.js)
// ============================================================

const API = typeof browser !== "undefined" ? browser : chrome;

function showToast(msg, ms) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), ms || 2500);
}

// ── Risk pill ─────────────────────────────────────────────────
function renderRiskPill(riskLevel, riskScore) {
  const pill  = document.getElementById("riskPill");
  const icons = { low:"✅", medium:"⚠️", high:"🚨", unknown:"❓" };
  const label = { low:"Low Risk", medium:"Medium Risk", high:"High Risk", unknown:"Scanning..." };
  pill.className = "risk-pill " + (riskLevel || "unknown");
  const pct = (riskScore != null && riskLevel !== "unknown") ? " (" + Math.round(riskScore * 100) + "%)" : "";
  pill.textContent = (icons[riskLevel] || "❓") + " " + (label[riskLevel] || riskLevel) + pct;
}

// ── Current site ──────────────────────────────────────────────
function loadCurrentRisk() {
  API.runtime.sendMessage({ type: "GET_CURRENT_RISK" }, (resp) => {
    if (API.runtime.lastError || !resp) { renderRiskPill("unknown"); return; }
    const result = resp.result || {};
    renderRiskPill(result.riskLevel || "unknown", result.riskScore);
    const urlEl = document.getElementById("currentUrl");
    try {
      const parsed = new URL(resp.url || "");
      urlEl.textContent = parsed.hostname + (parsed.pathname.length > 1 ? parsed.pathname.slice(0,25) : "");
    } catch { urlEl.textContent = resp.url ? resp.url.slice(0,50) : "—"; }
  });
}

// ── Stats ─────────────────────────────────────────────────────
function loadStats() {
  API.runtime.sendMessage({ type: "GET_STATS" }, (s) => {
    if (!s) return;
    document.getElementById("sTotal").textContent  = s.total      || 0;
    document.getElementById("sPhish").textContent  = s.phishing   || 0;
    document.getElementById("sSafe").textContent   = s.safe       || 0;
    document.getElementById("sAdult").textContent  = s.adult      || 0;
    document.getElementById("sBl").textContent     = s.blacklisted|| 0;
    document.getElementById("sBypass").textContent = s.bypassed   || 0;
  });
}

// ── Blacklist list ────────────────────────────────────────────
function renderBlacklist(list) {
  const container = document.getElementById("blList");
  if (!list || !list.length) {
    container.innerHTML = '<div class="empty-msg">No domains blacklisted yet</div>';
    return;
  }
  container.innerHTML = list.map(d =>
    '<div class="bl-item"><span>' + d + '</span>' +
    '<button data-d="' + d + '" title="Remove">✕</button></div>'
  ).join("");
  container.querySelectorAll("button[data-d]").forEach(btn => {
    btn.addEventListener("click", () => {
      API.runtime.sendMessage({ type: "REMOVE_FROM_BLACKLIST", domain: btn.dataset.d }, () => {
        showToast("Removed: " + btn.dataset.d);
        loadBlacklist();
      });
    });
  });
}

function loadBlacklist() {
  API.runtime.sendMessage({ type: "GET_BLACKLIST" }, (resp) => {
    renderBlacklist(resp && resp.list ? resp.list : []);
  });
}

// ── Buttons ───────────────────────────────────────────────────

// Scan current page
document.getElementById("btnScan").addEventListener("click", () => {
  API.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.id) return;
    API.tabs.sendMessage(tab.id, { type: "MANUAL_SCAN" }, () => {
      if (API.runtime.lastError) { showToast("Cannot reach page"); return; }
      showToast("Scanning...");
      setTimeout(loadCurrentRisk, 2000);
    });
  });
});

// Blacklist current site (one click)
document.getElementById("btnBlacklistCurrent").addEventListener("click", () => {
  API.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.url) { showToast("No active page"); return; }
    let domain = "";
    try { domain = new URL(tab.url).hostname.replace(/^www\./, ""); } catch {}
    if (!domain) { showToast("Cannot block this page"); return; }
    API.runtime.sendMessage({ type: "BLACKLIST_DOMAIN", domain }, (resp) => {
      if (resp && resp.success) {
        showToast("🚫 Blocked: " + domain);
        if (document.getElementById("blPanel").classList.contains("open")) loadBlacklist();
      } else {
        showToast("Failed to blacklist domain");
      }
    });
  });
});

// Toggle blacklist panel
document.getElementById("btnToggleBl").addEventListener("click", () => {
  const panel = document.getElementById("blPanel");
  const open  = panel.classList.toggle("open");
  if (open) loadBlacklist();
});

// Manual add domain from input
document.getElementById("btnAddManual").addEventListener("click", addManualDomain);
document.getElementById("blInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter") addManualDomain();
});

function addManualDomain() {
  const input = document.getElementById("blInput");
  let raw = input.value.trim();
  if (!raw) { showToast("Enter a domain or URL"); return; }
  // Strip protocol and path — accept full URLs too
  try {
    if (raw.includes("://")) raw = new URL(raw).hostname;
  } catch {}
  raw = raw.replace(/^www\./, "").replace(/\/.*$/, "").toLowerCase();
  if (!raw || !raw.includes(".")) { showToast("Invalid domain"); return; }
  API.runtime.sendMessage({ type: "BLACKLIST_DOMAIN", domain: raw }, (resp) => {
    if (resp && resp.success) {
      input.value = "";
      showToast("🚫 Blacklisted: " + raw);
      loadBlacklist();
    } else {
      showToast("Failed to add domain");
    }
  });
}

// ── Init ──────────────────────────────────────────────────────
loadCurrentRisk();
loadStats();
